<?php

include("db.php");

$id=$_GET['id'];

$result=mysqli_query($conn,"SELECT * FROM users WHERE id=$id");

$row=mysqli_fetch_array($result);

if(isset($_POST['update']))
{
    $username=$_POST['username'];
    $password=$_POST['password'];
    $phone=$_POST['phone'];
    $email=$_POST['email'];

    $image=$_FILES['profile']['name'];

    if($image!="")
    {
        move_uploaded_file($_FILES['profile']['tmp_name'],"uploads/".$image);

        mysqli_query($conn,"UPDATE users SET
        username='$username',
        password='$password',
        phone='$phone',
        email='$email',
        profile='$image'
        WHERE id=$id");
    }
    else
    {
        mysqli_query($conn,"UPDATE users SET
        username='$username',
        password='$password',
        phone='$phone',
        email='$email'
        WHERE id=$id");
    }

    header("Location:index.php");
}

?>

<html>

<head>
<title>Edit User</title>
</head>

<body>

<h2>Edit User</h2>

<form method="post" enctype="multipart/form-data">

Username :

<input type="text" name="username" value="<?php echo $row['username']; ?>">

<br><br>

Password :

<input type="text" name="password" value="<?php echo $row['password']; ?>">

<br><br>

Phone :

<input type="text" name="phone" value="<?php echo $row['phone']; ?>">

<br><br>

Email :

<input type="email" name="email" value="<?php echo $row['email']; ?>">

<br><br>

Current Image

<br>

<img src="uploads/<?php echo $row['profile']; ?>" width="50" height="50" style="border-radius:50%;">

<br><br>

New Picture :

<input type="file" name="profile">

<br><br>

<input type="submit" name="update" value="Update">

<a href="index.php">Back</a>

</form>

</body>

</html>