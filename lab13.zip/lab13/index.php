<?php
include("db.php");

if(isset($_POST['save']))
{
    $username=$_POST['username'];
    $password=$_POST['password'];
    $confirm=$_POST['confirm'];
    $phone=$_POST['phone'];
    $email=$_POST['email'];

    if($password==$confirm)
    {
        $image=$_FILES['profile']['name'];
        $tmp=$_FILES['profile']['tmp_name'];

        move_uploaded_file($tmp,"uploads/".$image);

        mysqli_query($conn,"INSERT INTO users(username,password,phone,email,profile)
        VALUES('$username','$password','$phone','$email','$image')");
    }
    else
    {
        echo "Password does not match";
    }
}
?>

<html>

<head>
<title>PHP CRUD</title>
</head>

<body>

<h2>User Registration</h2>

<form method="post" enctype="multipart/form-data">

Username :
<input type="text" name="username" required>

<br><br>

Password :
<input type="password" name="password" required>

<br><br>

Confirm Password :
<input type="password" name="confirm" required>

<br><br>

Phone :
<input type="text" name="phone" required>

<br><br>

Email :
<input type="email" name="email" required>

<br><br>

Profile Picture :
<input type="file" name="profile" required>

<br><br>

<input type="submit" name="save" value="Save">

</form>

<br><br>

<table border="1" cellpadding="10">

<tr>
<th>ID</th>
<th>Profile</th>
<th>Username</th>
<th>Password</th>
<th>Phone</th>
<th>Email</th>
<th>Action</th>
</tr>

<?php

$result=mysqli_query($conn,"SELECT * FROM users");

while($row=mysqli_fetch_array($result))
{

?>

<tr>

<td><?php echo $row['id']; ?></td>

<td>

<img src="uploads/<?php echo $row['profile']; ?>" width="50" height="50" style="border-radius:50%;">

</td>

<td><?php echo $row['username']; ?></td>

<td><?php echo $row['password']; ?></td>

<td><?php echo $row['phone']; ?></td>

<td><?php echo $row['email']; ?></td>

<td>

<a href="edit.php?id=<?php echo $row['id']; ?>">Edit</a>

|

<a href="delete.php?id=<?php echo $row['id']; ?>">Delete</a>

</td>

</tr>

<?php

}

?>

</table>

</body>

</html>