<?php
if (isset($_POST['submit'])) {
    $username = $_POST['username'];

    setcookie("username", $username, time() + 3600, "/");

    echo "Cookie has been created successfully.";
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Create Cookie</title>
</head>
<body>
    <form method="post">
        Enter Name:
        <input type="text" name="username" required>
        <input type="submit" name="submit" value="Create Cookie">
    </form>
</body>
</html>