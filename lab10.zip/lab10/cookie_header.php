<?php
setcookie("user", "John", time() + 3600, "/");

header("Location: welcome.php");
exit();
?>