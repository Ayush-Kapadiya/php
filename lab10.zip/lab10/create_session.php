<?php
session_start();

$_SESSION["username"] = "John";

echo "Session created successfully.<br>";
echo "Username: " . $_SESSION["username"];
?>